# GenieACS Web UI Final for Armbian

## Instalasi
```bash
git clone <repo>
cd genieacs-webui
npm install
node server/app.js
```

Akses di browser: `http://<IP-SERVER>:3002`
